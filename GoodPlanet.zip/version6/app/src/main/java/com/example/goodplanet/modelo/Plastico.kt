package com.example.goodplanet.modelo

data class Plastico(val nombre: String, val imagen: String)
