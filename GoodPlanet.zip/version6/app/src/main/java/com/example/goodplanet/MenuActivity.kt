package com.example.goodplanet

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.goodplanet.databinding.ActivityMenuBinding

class MenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //botones
        binding.btnEduc.setOnClickListener {
            Toast.makeText(this, "Te Explíco", Toast.LENGTH_LONG).show()
            val intento = Intent(this, MainActivity::class.java)
            startActivity(intento)
        }


        setSupportActionBar(findViewById(R.id.my_toolbar))
        supportActionBar!!.setDisplayHomeAsUpEnabled(false)
        supportActionBar!!.setIcon(R.mipmap.ic_launcher)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val REQUEST_IMAGE_CAPTURE = null
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            data?.extras?.let { bundle ->
                val imageBitmap = bundle.get("data") as Bitmap
                binding.shapeableImageView1.setImageBitmap(imageBitmap)
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_inicio_activity,menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.salir -> {
            finish()
            true
        }
        R.id.action_search -> {
            Toast.makeText(this,R.string.txt_action_search, Toast.LENGTH_LONG).show()
            true
        }
        R.id.action_phone -> {
            Toast.makeText(this, R.string.txt_action_phone, Toast.LENGTH_LONG).show()
            true
        }
        else -> {
            super.onOptionsItemSelected(item)
        }
    }
    fun onPhone(item: android.view.MenuItem) {
        val intento = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + "3168105790"))
        startActivity(intento)
    }



}
